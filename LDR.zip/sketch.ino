#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define OLED_SDA 21
#define OLED_SCL 22

#define LDR_PIN 34

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {

  Serial.begin(115200);

  // OLED I2C
  Wire.begin(OLED_SDA, OLED_SCL);

  // Start OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found!");
    while (1);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("LDR Light Monitor");

  display.display();

  delay(1000);
}

void loop() {

  // Read LDR
  int lightLevel = analogRead(LDR_PIN);

  // Serial Monitor
  Serial.print("Light Level: ");
  Serial.print(lightLevel);
  Serial.print("  Status: ");

  // OLED clear
  display.clearDisplay();

  // Title
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("LIGHT LEVEL");

  // Light value
  display.setTextSize(2);
  display.setCursor(20, 18);
  display.println(lightLevel);

  // Status
  display.setTextSize(1);
  display.setCursor(0, 50);

  if (lightLevel < 1200) {

    Serial.println("DARK");
    display.println("Status: DARK");

  }
  else if (lightLevel < 2800) {

    Serial.println("NORMAL");
    display.println("Status: NORMAL");

  }
  else {

    Serial.println("BRIGHT");
    display.println("Status: BRIGHT");

  }

  display.display();

  delay(500);
}